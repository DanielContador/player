/Library/Internet\ Plug-Ins/JavaAppletPlugin.plugin/Contents/Home/bin/java -jar compiler.jar --js scorm12_2004-api.js --compilation_level ADVANCED_OPTIMIZATIONS --js_output_file ssla.min.js
